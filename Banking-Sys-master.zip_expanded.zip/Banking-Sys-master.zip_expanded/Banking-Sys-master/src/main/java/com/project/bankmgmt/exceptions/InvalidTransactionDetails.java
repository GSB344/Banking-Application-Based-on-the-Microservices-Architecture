package com.project.bankmgmt.exceptions;

public class InvalidTransactionDetails extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTransactionDetails() {
		super("Invalid Transaction Details...");
	}
}
