create database if not exists bankingsys;
use database bankingsys;